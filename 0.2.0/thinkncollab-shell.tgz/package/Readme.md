# ThinkNCollab Shell V2 (`thinknsh`)

> **The Native-First Collaborative Developer OS: Lightweight MicroVM Sandbox & Zero-Daemon Dev Runner with Live Database Snapshots, P2P Terminal Multiplexing, and OCI Compatibility.**

[![npm version](https://img.shields.io/npm/v/thinkncollab-shell.svg)](https://www.npmjs.com/package/thinkncollab-shell)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-macOS%20%7C%20Linux%20%7C%20Windows%20(WSL2)-brightgreen.svg)](#platform-isolation-matrix)
[![Runtime](https://img.shields.io/badge/Runtime-Apple_Virtualization_%7C_crun_OCI-blueviolet.svg)](#core-capabilities)

---

## 🌟 What is ThinkNCollab Shell?

**ThinkNCollab Shell (`thinknsh`)** is a native-first development shell, process sandbox, and collaborative runtime built to eliminate everyday developer environment friction.

Instead of running a heavy 4GB+ RAM virtual machine daemon just to boot a local database, wrestling with teammate database migration drift, or sharing laggy video screens, **ThinkNCollab unifies your code, database, and terminal into a single peer-to-peer developer shell.**

---

## 📦 Containers: `thinknsh run`, `build`, `compose`

thinknsh has its own container engine, **dock**. You run, build and compose OCI containers with thinknsh commands. No other tool is needed. Images come from any OCI registry (the public one that hosts alpine, postgres and nginx works out of the box), containers run with `crun` on a real Linux kernel, and all state lives in one SQLite file. The daemon starts by itself on the first command.

```bash
thinknsh run --rm -it alpine sh                                   # interactive shell (Ctrl-P Ctrl-Q detaches)
thinknsh run -d --name db -e POSTGRES_PASSWORD=dev -p 5432:5432 postgres:16
thinknsh ps                                                       # -a for stopped ones too
thinknsh logs -f db
thinknsh exec -it db psql -U postgres
thinknsh build -t myapp .                                         # Dockerfile or Containerfile
thinknsh compose up -d                                            # compose.yaml in this folder
thinknsh compose logs -f
thinknsh compose down -v
```

Every command has its own help, for example `thinknsh run --help`. The full list:

| Area | Commands |
| :--- | :--- |
| Containers | `run`, `create`, `start`, `stop`, `restart`, `kill`, `rm`, `ps`, `logs`, `exec`, `wait`, `inspect` |
| Images | `images`, `pull`, `build`, `tag`, `rmi`, `image prune` |
| Apps | `compose up / down / ps / logs / exec / build / pull / start / stop / restart / rm / config` |
| Storage and networks | `volume ls / create / rm / inspect / prune`, `network ls / create / rm / connect / disconnect / prune` |
| Engine | `system info / df / prune`, `dock setup / start / stop / status / selftest / check` |

### What works today

| Feature | Status |
| :--- | :--- |
| Run, attach, interactive terminals, exec, logs, exit codes, signals | ✅ |
| Pull from public and private OCI registries | ✅ (registry login not yet, so private means no-auth) |
| Build: Dockerfile, multi-stage, build args, targets, layer cache, `.tncignore` | ✅ (`RUN --mount` and heredocs not yet) |
| Compose: build, depends_on with `service_healthy`, healthchecks, profiles, `.env`, recreate on change | ✅ (`extends`, `secrets` and `configs` not yet) |
| Networks with name resolution, named volumes, bind mounts, published TCP ports | ✅ (UDP not yet) |
| Push to a registry, registry login | ❌ not yet |
| Rootless mode | ❌ not yet |
| Deploy compose apps to your own servers | ✅ `thinknsh cluster deploy` |

### Platforms

| Platform | How containers run | Status |
| :--- | :--- | :--- |
| macOS, Apple Silicon (M1–M5) | Small Linux VM on Apple Virtualization.framework (`tnc-vz`). It boots on the first container and sleeps after 5 idle minutes. | ✅ Verified: unit, check suite, e2e, cluster and selftest |
| macOS, Intel | Same VM, x86_64 kernel | 🟡 Built, waiting for selftest reports |
| Windows 10/11, x64 or ARM64 | Dedicated WSL2 distro `tnc-dock`. `C:\` paths work in `-v`. The distro stops when idle. | 🟡 Built, waiting for selftest reports |
| Linux, x86_64 or aarch64 | Native namespaces and cgroups, no VM | 🟡 CI job set up, first results pending |

### Memory (measured, not estimated)

Measured on an Apple Silicon Mac with `thinknsh bench`. Run the same command on your machine to measure it there:

| State | Memory |
| :--- | :--- |
| dock running, VM asleep | ≈ 18 MB |
| VM awake, idle | ≈ 306 MB |
| postgres + redis running | ≈ 491–563 MB |

### Install

Downloads and the full guide are at **https://thinkncollab.com/dock**.

1. **Node.js 22.5 or newer.** dock stores its state with `node:sqlite`.
2. **Windows only:** turn on WSL2 in an administrator PowerShell, then reboot. If WSL is already installed, run `wsl --update` instead.
   ```powershell
   wsl --install --no-distribution
   ```
3. **Install thinknsh and the runtime.** `setup` picks the right files for your OS and CPU, checks every sha256 against the bundle manifest, and installs them:
   ```bash
   npm install -g https://thinkncollab.com/downloads/dock/0.2.0/thinkncollab-shell.tgz
   thinknsh dock setup
   ```
   On Linux, dock runs containers natively as root: run `sudo thinknsh dock setup` and `sudo thinknsh dock start`, then `sudo groupadd tnc-dock && sudo usermod -aG tnc-dock $USER` and restart dock to use the commands without sudo.
   On a machine without internet, download the files for your platform and `manifest.json` from the downloads page into one folder, then run `thinknsh dock setup --from <folder>`.
4. **Run something:**
   ```bash
   thinknsh run --rm -p 8080:80 nginx:alpine
   ```
   Then open http://localhost:8080.

### Check it works on your machine

```bash
thinknsh dock selftest     # 12 real checks; writes ~/.tnc/dock/selftest-<os>-<cpu>-<time>.json
thinknsh dock check        # engine API + thinknsh command suite (35 cases)
thinknsh bench idle        # memory, measured on this machine
```

If a check fails, send the selftest JSON file. It contains the machine details and the exact error of each check.

### For contributors: build and test from source

```bash
git clone -b shell/dock <repo> && cd ThinkNCollab-Shell-V2 && npm install
native/bundle/build.sh aarch64 dist-bundles     # also: x86_64, darwin (macOS only)
native/bundle/build.sh manifest dist-bundles 0.2.0
node bin/thinknsh.js dock setup --from dist-bundles
npm test                                       # unit tests (CLI, compose, engine, Windows backend)
node tests/dock-e2e.js                         # end to end against the running daemon
node bin/thinknsh.js dock check                # every command against the running daemon
```

Architecture and the runtime layout are documented in [`src/dock/README.md`](src/dock/README.md).

---

## ⚡ Core Capabilities

### 1. Dual Execution Engine: Native Microservices & Hardware-Accelerated OCI MicroVM
* **Hardware-Accelerated OCI MicroVM Engine:** Run standard OCI container images (`postgres:alpine`, `redis:alpine`, `nginx:alpine`, etc.) inside a lightweight, hardware-accelerated MicroVM on macOS (`tnc-vz`) or native cgroups/namespaces on Linux.
* **Stateful Services & Databases:** Fully supports stateful database engines (PostgreSQL, Redis, MySQL, MariaDB) with full environment variable propagation, POSIX dynamic shared memory (`/dev/shm`), and required Linux capabilities (`CAP_SYS_RESOURCE`, `CAP_IPC_LOCK`).
* **Hardware-Accelerated Linux MicroVM (`tnc-vz`):** On macOS, boots an Apple Virtualization MicroVM with real Linux namespaces, cgroups v2, and OCI `crun` runtime. Measured memory is listed in the dock section above.
* **VirtioFS Volume Mounts (`-v host:container`):** Seamless bidirectional filesystem sharing via Apple VirtioFS. Files edited on the host reflect instantly inside containers and vice versa.
* **Live Process Telemetry & Top:** Real live metrics via `thinknsh top` (querying container PIDs inside the Linux namespace) and `thinknsh stats` (streaming real RSS memory and CPU ticks directly from container `/proc`).
* **Host Port Conflict Protection:** Validates host port availability before launch, safeguarding local running databases from being clobbered or killed.
* **Native Host Services Fallback:** Detects local system Postgres (`pg_ctl`) and Redis (`redis-server`) binaries to run lean dev dependencies with zero VM overhead when preferred.
* **Instant Process Freeze/Resume:** Pauses background services to reclaim CPU and memory without destroying container bundles.

### 2. Multi-Layer Collaborative State Sync (`room share` / `room pull`)
* Share entire development environments between teammates in seconds without third-party registries.
* **Encrypted Multi-Layer Bundle:** Packages workspace code, live database snapshots (Postgres, Mongo, Redis), and sanitized `.env` secrets into a single AES-256-GCM encrypted bundle.
* **Hybrid Transport:** Direct Gigabit Wi-Fi LAN P2P mesh (zero cloud bandwidth) with automatic fallback to ephemeral in-memory cloud socket relays.

### 3. Smart 3-Way Code & Secret Merge Engine
* **Non-Destructive:** Local files created by developers are never deleted during sync.
* **Git 3-Way Line Merge (`git merge-file`):** Non-conflicting edits auto-merge with zero conflicts. Overlapping edits receive standard conflict markers (`<<<<<<< LOCAL` ... `>>>>>>> INCOMING`), activating VS Code's interactive CodeLens UI.
* **Smart `.env` Reconciliation:** Preserves local developer overrides (custom ports, local keys) while appending missing teammate secrets.
* **1-Click Safety Undo (`room undo`):** Pre-merge safety snapshots allow instant rollback if desired.

### 4. Low-Bandwidth Terminal Multiplexing
* **Semantic ANSI Text vs Video Pixels:** Streams UTF-8 terminal text chunks over WebSockets instead of rendering video frames, eliminating screen sharing latency and blur.
* **Sub-Millisecond Dynamic RBAC:** Grant and revoke peer keyboard input access in real-time.
* **AAD Replay Defense:** Cryptographically binds Additional Authenticated Data (`term-input:${sessionId}:${senderId}:${roomId}:${seq}`) to prevent keystroke replay attacks.
* **Emergency Host Lock:** Instantly drop all remote input with one command.

### 5. Signal-Grade E2EE Security
* **60-Digit Out-of-Band Safety Numbers:** Verify channels on calls to guarantee zero MITM interception.
* **TOFU Registry:** Trust-On-First-Use cryptographic registry for peer public keys.
* **Forward Secrecy Key Rotation (`room rotate-key`):** Automatically rekeys rooms when members leave, preventing evicted members from decrypting future streams or states.

---

## 🖥️ Terminal Sharing Architecture

ThinkNCollab terminal pair programming operates on semantic text streams rather than video capture:

* **Text Streams Over WebSocket:** Raw PTY output (ANSI escape sequences and UTF-8 characters) is encrypted and streamed directly to connected peers, rendering natively in their local terminal client.
* **Zero Video Overhead:** Avoids high-bandwidth video encoding/decoding, delivering sharp text reproduction and minimal latency even over constrained networks.
* **Cryptographic Session Integrity:** Every keystroke packet is tagged with an incremental sequence counter and AES-256-GCM authentication tag bound to the active room, session, and peer identity.

---

## 📋 Platform Isolation Matrix

| Capability | macOS | Linux | Windows (WSL2) |
| :--- | :--- | :--- | :--- |
| **Isolation Primitive** | Apple Virtualization (`tnc-vz` MicroVM + `crun`) / Seatbelt fallback | Kernel namespaces (`unshare` / `crun`) | WSL2 utility environment |
| **Resource Caps** | Dynamic Memory Ballooning + VirtioFS | `cgroups v2` (memory, CPU, pids) | WSL2 cgroups v2 |
| **Networking & Discovery** | Native `vsock` relay + Virtio-Net | Virtual bridge + veth + iptables | Netsh port proxy + localhost |
| **Snapshot Strategy** | APFS Copy-on-Write (`cp -cR`) | Btrfs / XFS reflink (`--reflink=auto`) | VSS / Directory copy fallback |

---

## 🚀 Installation & Quick Start

```bash
# Install globally via npm
npm install -g thinkncollab-shell

# Or run instantly via npx
npx thinkncollab-shell
```

Both `thinknsh` and `tnc` command shortcuts are registered:

```bash
thinknsh --version
# 2.0.0
```

---

## 💻 CLI Cheat Sheet

### Containers
```bash
thinknsh run -d --name pg -p 5433:5432 -e POSTGRES_PASSWORD=secret postgres:alpine
thinknsh run -d --name cache -p 6379:6379 -m 512m redis:alpine
thinknsh ps
thinknsh exec pg psql -U postgres -c "SELECT version();"
thinknsh logs -f pg
thinknsh stop pg && thinknsh rm pg
thinknsh compose up -d
```

### Room State & Database Sync
```bash
thinknsh room share [name]         # Publish code, Postgres, Mongo & Redis state
thinknsh room share --no-code      # Publish database & environment only
thinknsh room pull [state-id]      # Smart-merge teammate state into workspace
thinknsh room merge [state-id]     # Explicit 3-way merge
thinknsh room undo                 # Rollback last merge from safety backup
thinknsh room states               # List shared states with service & code indicators
thinknsh room verify               # Display 60-digit E2EE safety number & TOFU peers
thinknsh room rotate-key           # Rekey room for forward secrecy
```

### Real-Time Terminal Pair Programming
```bash
thinknsh share                     # Start real-time PTY terminal sharing session
thinknsh share --readonly          # Start in read-only broadcast mode
```

### Native Sandboxes & Process Control
```bash
thinknsh dev --port 3000           # Launch service in native process sandbox
thinknsh ps                        # Inspect active sandboxes & memory usage
thinknsh freeze <name>             # Pause sandbox process (0% CPU/RAM)
thinknsh resume <name>             # Resume paused sandbox instantly
thinknsh snapshot create <name>    # Create sub-second CoW volume snapshot
thinknsh snapshot restore <name>   # Restore volume state
```

### Multi-Language Package Manager (`dep`)
```bash
thinknsh dep install <pkg>         # Track & install package across npm/pip/cargo/go
thinknsh dep list                  # List all tracked dependencies
thinknsh dep sync                  # Reconcile environment from thinkncollab.yml
```

---

## 📄 License

Apache License 2.0. See [LICENSE](LICENSE) for details.  
Copyright (c) 2024-2026 ThinkNCollab Systems Inc. All rights reserved.